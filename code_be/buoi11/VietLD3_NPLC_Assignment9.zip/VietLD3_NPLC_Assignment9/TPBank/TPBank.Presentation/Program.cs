﻿namespace TPBank.Presentation
{
    public class Program
    {
        static void Main(string[] args)
        {
            var managers = new TPBankManagement();
            managers.Menu();
        }
    }
}