﻿using NPLC.Assignment11.Controller;

namespace NPLC.Assignment11
{
    public class Program
    {
        static void Main(string[] args)
        {
            Management manage = new Management();
            manage.Manage();
        }
    }
}
