﻿using FA.JustBlog.Core.Models;
using FA.JustBlog.Core.Repositories.Generic;

namespace FA.JustBlog.Core.Repositories
{
    public interface ICategoryRepository : IGenericRepository<Category>
    {
        public Category GetTagByUrlSlug(string urlSlug);
    }
}
