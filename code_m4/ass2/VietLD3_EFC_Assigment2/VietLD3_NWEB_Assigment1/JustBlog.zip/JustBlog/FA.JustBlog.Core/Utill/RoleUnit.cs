﻿namespace FA.JustBlog.Core.Utill
{
    public class RoleUnit
    {
        public const string? Role_User = "User";
        public const string? Role_Contributor = "Contributor";
        public const string? Role_BlogOwner = "Blog Owner";
    }
}
