﻿namespace FA.JustBlog.ViewModel.ViewModel
{
    public class PostTagMapViewModel
    {
        public int PostId { get; set; }
        public PostViewModel Post { get; set; }
        public int TagId { get; set; }
        public TagViewModel Tag { get; set; }

    }
}
