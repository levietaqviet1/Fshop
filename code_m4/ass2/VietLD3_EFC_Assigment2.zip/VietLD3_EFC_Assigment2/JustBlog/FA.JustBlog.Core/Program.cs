﻿namespace FA.JustBlog.Core
{
    internal class Program
    {
    }
}
