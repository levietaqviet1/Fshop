﻿namespace NWEB.Practice.T01.Core.Utill
{
    public class RoleUnit
    {
        public const string? Role_User = "User";
        public const string? Role_Admin = "Admin";
    }
}
