﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using NWEB.Practice.T01.Core.Model;

namespace NWEB.Practice.T01.Core.DataContext
{
    public static class FlowerStoreInitializer
    {
        /// <summary>
        /// viet hoa
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private static string Uppercase(string name) { return name.ToUpper(); }
        /// <summary>
        /// add data for database
        /// </summary>
        /// <param name="builder"></param>
        public static void SeedData(this ModelBuilder builder)
        {

            builder.Entity<IdentityRole>().HasData
              (
                  new IdentityRole
                  {
                      Id = "db1782c7-bf14-41f7-bc1f-950128ecb3bd",
                      Name = "User",
                      NormalizedName = Uppercase("User"),
                      ConcurrencyStamp = "b11bbed6-4919-4f52-a4b1-c45091a8fbf0"
                  },
                  new IdentityRole
                  {
                      Id = "db5782c7-bf14-41f7-bc1f-950128ecb3bb",
                      Name = "Admin",
                      NormalizedName = Uppercase("Admin"),
                      ConcurrencyStamp = "b31bbed6-4919-4f52-a4b1-c45091a8fbf0"
                  }
              );

            builder.Entity<UsingIdentityUser>().HasData
                (
                    // toàn bộ mật khẩu Abc@123

                    new UsingIdentityUser
                    {
                        Id = "97571dcc-079e-4c3a-ba9b-bbde3d03a03d",
                        Firstname = "Viet",
                        LastName = "Le",
                        UserName = "vietContributor@gmail.com",
                        NormalizedUserName = Uppercase("vietContributor@gmail.com"),
                        Email = "vietContributor@gmail.com",
                        NormalizedEmail = Uppercase("vietContributor@gmail.com"),
                        EmailConfirmed = true,
                        PasswordHash = "AQAAAAEAACcQAAAAEJ51SmQrANatorjKkODvG7wRz8i73uIAUIHAmXRldg8ikayfZiaDQvbSOuY+XFPiJQ==",
                        PhoneNumberConfirmed = true,
                        TwoFactorEnabled = false,
                        LockoutEnabled = false,
                        AccessFailedCount = 0,
                        PhoneNumber = "0985695635",

                    },
                     new UsingIdentityUser
                     {
                         Id = "21842bcb-fae8-4c00-9c33-de997d4e8103",
                         Firstname = "Khi",
                         LastName = "nguyen",
                         UserName = "vietBlogOwner@gmail.com",
                         NormalizedUserName = Uppercase("vietBlogOwner@gmail.com"),
                         Email = "vietBlogOwner@gmail.com",
                         NormalizedEmail = Uppercase("vietBlogOwner@gmail.com"),
                         EmailConfirmed = true,
                         PasswordHash = "AQAAAAEAACcQAAAAEGf8AICmlUDtMuw9p1TPGYB0/OH8X60Ud06sUakpWa+Tpu2IJAZvF6Ht7DxsYeWEjA==",
                         PhoneNumberConfirmed = true,
                         TwoFactorEnabled = false,
                         LockoutEnabled = false,
                         AccessFailedCount = 0,
                         PhoneNumber = "045896589",
                     },
                     new UsingIdentityUser
                     {
                         Id = "21811bcb-fae8-4c00-9c33-de997d4e8107",
                         Firstname = "Viet",
                         LastName = "User",
                         UserName = "vietUser.com",
                         NormalizedUserName = Uppercase("vietUser@gmail.com"),
                         Email = "vietUser@gmail.com",
                         NormalizedEmail = Uppercase("vietUser@gmail.com"),
                         EmailConfirmed = true,
                         PasswordHash = "AQAAAAEAACcQAAAAEGf8AICmlUDtMuw9p1TPGYB0/OH8X60Ud06sUakpWa+Tpu2IJAZvF6Ht7DxsYeWEjA==",
                         PhoneNumberConfirmed = true,
                         TwoFactorEnabled = false,
                         LockoutEnabled = false,
                         AccessFailedCount = 0,
                         PhoneNumber = "0922556369",
                     },
                      new UsingIdentityUser
                      {
                          Id = "b0446349-235d-4b0f-a8e9-87382a82923f",
                          Firstname = "Toan",
                          LastName = "Nguyen",
                          UserName = "user@gmail.com",
                          NormalizedUserName = Uppercase("user@gmail.com"),
                          Email = "user@gmail.com",
                          NormalizedEmail = Uppercase("user@gmail.com"),
                          EmailConfirmed = true,
                          PasswordHash = "AQAAAAEAACcQAAAAED7S01cmZYmeJEKd7/wVP+HGOCSHbR/Xl2NRWyWTXB6JbwfXREcO2D908cRKtFG2Ag==",
                          PhoneNumberConfirmed = true,
                          TwoFactorEnabled = false,
                          LockoutEnabled = false,
                          AccessFailedCount = 0,
                          PhoneNumber = "0458796598",
                      }
                );

            builder.Entity<IdentityUserRole<string>>().HasData
                (
                    new IdentityUserRole<string>
                    {
                        RoleId = "db5782c7-bf14-41f7-bc1f-950128ecb3bb",
                        UserId = "97571dcc-079e-4c3a-ba9b-bbde3d03a03d"
                    },
                    new IdentityUserRole<string>
                    {
                        RoleId = "db5782c7-bf14-41f7-bc1f-950128ecb3bb",
                        UserId = "21842bcb-fae8-4c00-9c33-de997d4e8103"
                    },
                    new IdentityUserRole<string>
                    {
                        RoleId = "db1782c7-bf14-41f7-bc1f-950128ecb3bd",
                        UserId = "21811bcb-fae8-4c00-9c33-de997d4e8107"
                    },
                    new IdentityUserRole<string>
                    {
                        RoleId = "db1782c7-bf14-41f7-bc1f-950128ecb3bd",
                        UserId = "b0446349-235d-4b0f-a8e9-87382a82923f"
                    }
                );


            builder.Entity<Category>().HasData(
                new Category
                {
                    Id = 1,
                    Name = "Rose",
                    Order = 3,
                    Notes = "Genus of some 100 species of perennial shrubs in the rose family (Rosaceae). Roses are native primarily to the temperate regions of the Northern Hemisphere."
                },
                new Category
                {
                    Id = 2,
                    Name = "Chrysanthemum",
                    Order = 3,
                    Notes = "The genus Chrysanthemum are perennial herbaceous flowering plants, sometimes subshrubs. The leaves are alternate, divided into leaflets and may be pinnatisect, lobed, or serrate (toothed) but rarely entire; they are connected to stalks with hairy bases."
                },
                new Category
                {
                    Id = 3,
                    Name = "Tulip",
                    Order = 3,
                    Notes = "are a genus of spring-blooming perennial herbaceous bulbiferous geophytes (having bulbs as storage organs). The flowers are usually large, showy and brightly coloured, generally red, pink, yellow, or white (usually in warm colours)."
                },
                new Category
                {
                    Id = 4,
                    Name = "Lilium",
                    Order = 3,
                    Notes = "Is a genus of herbaceous flowering plants growing from bulbs, all with large prominent flowers. They are the true lilies. Lilies are a group of flowering plants which are important in culture and literature in much of the world. "
                },
                new Category
                {
                    Id = 5,
                    Name = "Jasmine ",
                    Order = 3,
                    Notes = "Is a genus of shrubs and vines in the olive family of Oleaceae.  It contains around 200 species native to tropical and warm temperate regions of Eurasia, Africa, and Oceania."
                }
                );
            builder.Entity<Flower>().HasData(
                new Flower
                {
                    Id = 1,
                    Name = "Red roses",
                    CategoryId = 1,
                    Description = "Red roses are a symbol of romantic love, passion, commitment, faithfulness, and loyalty",
                    Color = "Red",
                    Image = "",
                    Price = 100000,
                    SalePrice = 0,
                    StoreDate = DateTime.Now,
                    StoreInventory = 10000
                },
                new Flower
                {
                    Id = 2,
                    Name = "Chrysanthemum",
                    CategoryId = 2,
                    Description = "Chrysanthemum are a symbol of romantic love, passion, commitment, faithfulness, and loyalty",
                    Color = "Yellow",
                    Image = "",
                    Price = 10000,
                    SalePrice = 10,
                    StoreDate = DateTime.Now,
                    StoreInventory = 100000
                },
                new Flower
                {
                    Id = 3,
                    Name = "Tulip",
                    CategoryId = 3,
                    Description = "Tulipare a symbol of romantic love, passion, commitment, faithfulness, and loyalty",
                    Color = "Lavender",
                    Image = "",
                    Price = 100000,
                    SalePrice = 0,
                    StoreDate = DateTime.Now,
                    StoreInventory = 10000
                },
                new Flower
                {
                    Id = 4,
                    Name = "Lilium",
                    CategoryId = 4,
                    Description = "Lilium are a symbol of romantic love, passion, commitment, faithfulness, and loyalty",
                    Color = "Blue",
                    Image = "",
                    Price = 20000,
                    SalePrice = 5,
                    StoreDate = DateTime.Now,
                    StoreInventory = 1000
                },
                new Flower
                {
                    Id = 5,
                    Name = "Jasmine",
                    CategoryId = 1,
                    Description = "Jasmine are a symbol of romantic love, passion, commitment, faithfulness, and loyalty",
                    Color = "Pink",
                    Image = "",
                    Price = 10000,
                    SalePrice = 13,
                    StoreDate = DateTime.Now,
                    StoreInventory = 10000
                }
                );
        }
    }
}
