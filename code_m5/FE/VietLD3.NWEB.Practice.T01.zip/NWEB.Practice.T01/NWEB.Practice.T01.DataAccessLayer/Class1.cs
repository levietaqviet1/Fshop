﻿namespace NWEB.Practice.T01.DataAccessLayer
{
    public class Class1
    {

    }
}